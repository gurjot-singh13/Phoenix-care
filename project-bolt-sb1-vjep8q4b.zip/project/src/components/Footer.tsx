import React from 'react';
import { Phone, Mail } from 'lucide-react';
import { useThemeStore } from '../stores/themeStore';

const Footer = () => {
  const { isDarkMode } = useThemeStore();
  
  return (
    <footer className={`mt-auto py-8 ${isDarkMode ? 'dark bg-gray-800 text-white' : 'bg-gray-100'}`}>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Emergency Contacts</h3>
            <div className="space-y-2">
              <p className="flex items-center"><Phone size={16} className="mr-2" /> Emergency: 102</p>
              <p className="flex items-center"><Phone size={16} className="mr-2" /> Ambulance: 108</p>
              <p className="flex items-center"><Phone size={16} className="mr-2" /> Mental Health Helpline: 1800-599-0019</p>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/disease-detection">Disease Detection</a></li>
              <li><a href="/mental-health">Mental Health Support</a></li>
              <li><a href="/doctors">Find Doctors</a></li>
              <li><a href="/community">Community</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Contact Us</h3>
            <div className="space-y-2">
              <p className="flex items-center">
                <Mail size={16} className="mr-2" /> support@phoenixcare.in
              </p>
              <p>Available 24/7 for emergencies</p>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-4 border-t text-center">
          <p>&copy; {new Date().getFullYear()} Phoenix Care. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;