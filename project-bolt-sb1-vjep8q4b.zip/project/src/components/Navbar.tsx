import React from 'react';
import { Link } from 'react-router-dom';
import { Sun, Moon, Menu } from 'lucide-react';
import { useThemeStore } from '../stores/themeStore';

const Navbar = () => {
  const { isDarkMode, toggleTheme } = useThemeStore();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <nav className={`${isDarkMode ? 'dark bg-gray-800 text-white' : 'bg-white'} shadow-lg`}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-2xl font-bold">Phoenix Care</span>
          </Link>

          <div className="hidden md:flex items-center space-x-6">
            <Link to="/disease-detection" className="hover:text-blue-500">Disease Detection</Link>
            <Link to="/mental-health" className="hover:text-blue-500">Mental Health</Link>
            <Link to="/doctors" className="hover:text-blue-500">Doctors</Link>
            <Link to="/community" className="hover:text-blue-500">Community</Link>
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>

          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu size={24} />
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden pb-4">
            <Link to="/disease-detection" className="block py-2">Disease Detection</Link>
            <Link to="/mental-health" className="block py-2">Mental Health</Link>
            <Link to="/doctors" className="block py-2">Doctors</Link>
            <Link to="/community" className="block py-2">Community</Link>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;