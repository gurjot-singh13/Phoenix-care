import React, { useState } from 'react';
import { Send } from 'lucide-react';

const responses = {
  greeting: [
    "Hello! I'm here to support you. How are you feeling today?",
    "Hi there! I'm your mental health companion. Would you like to talk about how you're feeling?",
    "Welcome! I'm here to listen and help. What's on your mind?",
  ],
  anxiety: [
    "I hear that you're feeling anxious. Let's try a simple breathing exercise together. Would that help?",
    "Anxiety can be overwhelming. Would you like to explore some coping strategies?",
    "It's okay to feel anxious. Can you tell me what triggered these feelings?",
  ],
  depression: [
    "I understand you're going through a difficult time. Have you been able to talk to anyone else about this?",
    "Depression can make everything feel harder. What usually helps you feel a bit better?",
    "You're not alone in this. Would you like to explore some self-care activities together?",
  ],
  stress: [
    "Stress can be really challenging. Let's identify what's causing you the most pressure right now.",
    "When we're stressed, it helps to break things down into smaller steps. Shall we try that?",
    "I understand you're feeling stressed. Would you like to learn some quick relaxation techniques?",
  ],
  default: [
    "I'm here to support you. Can you tell me more about that?",
    "Thank you for sharing. How long have you been feeling this way?",
    "I'm listening. What would be most helpful for you right now?",
    "Your feelings are valid. Would you like to explore this further?",
  ]
};

const getAIResponse = (message: string) => {
  const lowerMessage = message.toLowerCase();
  let responseArray = responses.default;

  if (lowerMessage.includes('anxious') || lowerMessage.includes('anxiety') || lowerMessage.includes('worried')) {
    responseArray = responses.anxiety;
  } else if (lowerMessage.includes('depress') || lowerMessage.includes('sad') || lowerMessage.includes('hopeless')) {
    responseArray = responses.depression;
  } else if (lowerMessage.includes('stress') || lowerMessage.includes('overwhelm') || lowerMessage.includes('pressure')) {
    responseArray = responses.stress;
  }

  return responseArray[Math.floor(Math.random() * responseArray.length)];
};

const MentalHealth = () => {
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{type: 'user' | 'bot', message: string}>>([
    {
      type: 'bot',
      message: responses.greeting[Math.floor(Math.random() * responses.greeting.length)]
    }
  ]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    // Add user message to chat
    setChatHistory(prev => [...prev, { type: 'user', message }]);
    
    // Get AI response
    const aiResponse = getAIResponse(message);
    setMessage('');

    // Simulate thinking time
    setTimeout(() => {
      setChatHistory(prev => [...prev, {
        type: 'bot',
        message: aiResponse
      }]);
    }, Math.random() * 500 + 500); // Random delay between 500-1000ms
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Mental Health Support</h1>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
        <div className="h-[500px] flex flex-col">
          <div className="flex-1 overflow-y-auto mb-4 space-y-4">
            {chatHistory.map((chat, index) => (
              <div
                key={index}
                className={`flex ${chat.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-4 ${
                    chat.type === 'user'
                      ? 'bg-primary-500 text-white'
                      : 'bg-gray-100 dark:bg-gray-700'
                  }`}
                >
                  {chat.message}
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message..."
              className="input flex-1"
            />
            <button
              type="submit"
              className="btn btn-primary px-6"
              disabled={!message.trim()}
            >
              <Send size={20} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default MentalHealth;