import React from 'react';
import { Link } from 'react-router-dom';
import { Brain, Eye, Users, MessageSquare, Stethoscope } from 'lucide-react';

const Home = () => {
  return (
    <div className="space-y-12">
      <section className="text-center py-16 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Welcome to Phoenix Care</h1>
        <p className="text-xl mb-8">Your AI-Powered Healthcare Companion</p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link
            to="/disease-detection"
            className="bg-white text-blue-600 px-6 py-3 rounded-full font-semibold hover:bg-blue-50 transition"
          >
            Start Detection
          </Link>
          <Link
            to="/mental-health"
            className="bg-transparent border-2 border-white text-white px-6 py-3 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition"
          >
            Talk to AI
          </Link>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <FeatureCard
          icon={<Eye className="w-12 h-12 text-blue-500" />}
          title="Disease Detection"
          description="Upload images for instant AI analysis of skin and eye conditions"
          link="/disease-detection"
        />
        <FeatureCard
          icon={<Brain className="w-12 h-12 text-purple-500" />}
          title="Mental Health Support"
          description="24/7 AI chatbot for mental health guidance and support"
          link="/mental-health"
        />
        <FeatureCard
          icon={<Stethoscope className="w-12 h-12 text-green-500" />}
          title="Doctor Directory"
          description="Find and connect with healthcare professionals near you"
          link="/doctors"
        />
      </section>

      <section className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8">
        <h2 className="text-3xl font-bold mb-6 text-center">Why Choose Phoenix Care?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="flex items-start space-x-4">
            <Users className="w-8 h-8 text-blue-500 flex-shrink-0" />
            <div>
              <h3 className="text-xl font-semibold mb-2">Community Support</h3>
              <p>Connect with others, share experiences, and learn from the community</p>
            </div>
          </div>
          <div className="flex items-start space-x-4">
            <MessageSquare className="w-8 h-8 text-green-500 flex-shrink-0" />
            <div>
              <h3 className="text-xl font-semibold mb-2">24/7 AI Support</h3>
              <p>Get instant responses and guidance anytime, anywhere</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

const FeatureCard = ({ icon, title, description, link }) => (
  <Link to={link} className="block p-6 bg-white dark:bg-gray-800 rounded-lg shadow-lg hover:shadow-xl transition">
    <div className="flex flex-col items-center text-center">
      {icon}
      <h3 className="text-xl font-semibold mt-4 mb-2">{title}</h3>
      <p className="text-gray-600 dark:text-gray-300">{description}</p>
    </div>
  </Link>
);

export default Home;