import React, { useState, useRef } from 'react';
import { Camera, Upload, AlertCircle } from 'lucide-react';

// Mock disease detection database
const diseasePatterns = [
  {
    name: "Acne",
    patterns: ["red spots", "inflammation", "pimples", "facial"],
    severity: "low",
    recommendations: [
      "Keep the affected area clean",
      "Avoid touching or picking",
      "Use over-the-counter acne treatment",
      "Consider consulting a dermatologist if persistent"
    ]
  },
  {
    name: "Conjunctivitis",
    patterns: ["red eye", "eye inflammation", "pink eye"],
    severity: "medium",
    recommendations: [
      "Avoid touching or rubbing eyes",
      "Use a cool compress",
      "Consult an eye doctor",
      "Keep the eye area clean"
    ]
  },
  {
    name: "Eczema",
    patterns: ["dry skin", "rash", "itchy", "patches"],
    severity: "medium",
    recommendations: [
      "Keep skin moisturized",
      "Avoid triggers",
      "Use prescribed creams",
      "Consider seeing a dermatologist"
    ]
  }
];

const DiseaseDetection = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<{
    disease: string;
    severity: string;
    recommendations: string[];
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const analyzeImage = () => {
    setLoading(true);
    
    // Simulate AI analysis with random selection and delay
    setTimeout(() => {
      const randomDisease = diseasePatterns[Math.floor(Math.random() * diseasePatterns.length)];
      setAnalysis({
        disease: randomDisease.name,
        severity: randomDisease.severity,
        recommendations: randomDisease.recommendations
      });
      setLoading(false);
    }, 2000);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setAnalysis(null); // Reset previous analysis
      };
      reader.readAsDataURL(file);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'text-green-500';
      case 'medium':
        return 'text-yellow-500';
      case 'high':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Disease Detection</h1>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
        <div className="space-y-6">
          <div className="text-center">
            <h2 className="text-xl font-semibold mb-2">Upload an Image</h2>
            <p className="text-gray-600 dark:text-gray-300">
              Upload a clear image of the affected area for analysis
            </p>
          </div>

          <div className="flex flex-col items-center space-y-4">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              className="hidden"
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="btn btn-primary flex items-center justify-center space-x-2"
              >
                <Upload size={20} />
                <span>Upload Image</span>
              </button>
              
              <button
                className="btn btn-secondary flex items-center justify-center space-x-2"
              >
                <Camera size={20} />
                <span>Take Photo</span>
              </button>
            </div>

            {selectedImage && (
              <div className="w-full max-w-md space-y-4">
                <img
                  src={selectedImage}
                  alt="Selected"
                  className="w-full h-auto rounded-lg shadow-md"
                />
                
                <button
                  onClick={analyzeImage}
                  disabled={loading}
                  className="btn btn-primary w-full"
                >
                  {loading ? 'Analyzing...' : 'Analyze Image'}
                </button>
              </div>
            )}

            {analysis && (
              <div className="w-full max-w-md bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
                <div className="space-y-4">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-5 h-5 mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold">Detected Condition</h3>
                      <p className="text-lg">{analysis.disease}</p>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-1">Severity</h3>
                    <p className={`capitalize ${getSeverityColor(analysis.severity)}`}>
                      {analysis.severity}
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">Recommendations</h3>
                    <ul className="list-disc list-inside space-y-1">
                      {analysis.recommendations.map((rec, index) => (
                        <li key={index}>{rec}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-4 border-t">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Note: This is an initial assessment only. Please consult a healthcare professional for accurate diagnosis and treatment.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiseaseDetection;