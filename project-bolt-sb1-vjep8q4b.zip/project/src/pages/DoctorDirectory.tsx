import React from 'react';
import { MapPin, Phone, Mail, Star } from 'lucide-react';

const doctors = [
  {
    id: 1,
    name: 'Dr. Priya Sharma',
    specialty: 'Dermatologist',
    location: 'Mumbai, Maharashtra',
    rating: 4.8,
    experience: '15 years',
    phone: '+91 98765 43210',
    email: 'dr.priya@phoenixcare.in',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300&h=300'
  },
  {
    id: 2,
    name: 'Dr. Rajesh Kumar',
    specialty: 'Ophthalmologist',
    location: 'Delhi, NCR',
    rating: 4.9,
    experience: '20 years',
    phone: '+91 98765 43211',
    email: 'dr.rajesh@phoenixcare.in',
    image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=300&h=300'
  },
  {
    id: 3,
    name: 'Dr. Anjali Desai',
    specialty: 'Psychiatrist',
    location: 'Bangalore, Karnataka',
    rating: 4.7,
    experience: '12 years',
    phone: '+91 98765 43212',
    email: 'dr.anjali@phoenixcare.in',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&q=80&w=300&h=300'
  }
];

const DoctorDirectory = () => {
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Find a Doctor</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {doctors.map((doctor) => (
          <div key={doctor.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
            <img
              src={doctor.image}
              alt={doctor.name}
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h2 className="text-xl font-semibold mb-2">{doctor.name}</h2>
              <p className="text-primary-600 dark:text-primary-400 font-medium mb-4">
                {doctor.specialty}
              </p>
              
              <div className="space-y-2 text-gray-600 dark:text-gray-300">
                <div className="flex items-center">
                  <MapPin size={18} className="mr-2" />
                  <span>{doctor.location}</span>
                </div>
                <div className="flex items-center">
                  <Star size={18} className="mr-2 text-yellow-500" />
                  <span>{doctor.rating} / 5.0</span>
                </div>
                <div className="flex items-center">
                  <Phone size={18} className="mr-2" />
                  <span>{doctor.phone}</span>
                </div>
                <div className="flex items-center">
                  <Mail size={18} className="mr-2" />
                  <span>{doctor.email}</span>
                </div>
              </div>

              <div className="mt-6">
                <button className="btn btn-primary w-full">
                  Book Appointment
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DoctorDirectory;