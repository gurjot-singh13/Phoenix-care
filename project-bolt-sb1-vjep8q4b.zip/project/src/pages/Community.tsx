import React, { useState } from 'react';
import { MessageSquare, ThumbsUp, Share2 } from 'lucide-react';

const initialPosts = [
  {
    id: 1,
    author: "Amit Patel",
    title: "Living with Psoriasis: My Journey",
    content: "I have been dealing with psoriasis for the past 5 years, and I wanted to share some tips that have helped me manage it...",
    likes: 24,
    comments: 8,
    timestamp: "2 hours ago"
  },
  {
    id: 2,
    author: "Meera Singh",
    title: "Anxiety Management Techniques",
    content: "After struggling with anxiety for years, I have found these breathing exercises to be incredibly helpful...",
    likes: 45,
    comments: 15,
    timestamp: "5 hours ago"
  },
  {
    id: 3,
    author: "Dr. Kavita Reddy",
    title: "Understanding Eye Strain in the Digital Age",
    content: "As an ophthalmologist, I often see patients with digital eye strain. Here are some preventive measures...",
    likes: 67,
    comments: 22,
    timestamp: "1 day ago"
  }
];

const Community = () => {
  const [posts, setPosts] = useState(initialPosts);
  const [newPost, setNewPost] = useState({ title: "", content: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPost.title.trim() || !newPost.content.trim()) return;

    const post = {
      id: posts.length + 1,
      author: "You",
      title: newPost.title,
      content: newPost.content,
      likes: 0,
      comments: 0,
      timestamp: "Just now"
    };

    setPosts([post, ...posts]);
    setNewPost({ title: "", content: "" });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Community</h1>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Share Your Experience</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Title"
            value={newPost.title}
            onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
            className="input"
          />
          <textarea
            placeholder="Share your story or ask a question..."
            value={newPost.content}
            onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
            className="input min-h-[120px]"
          />
          <button type="submit" className="btn btn-primary">
            Post
          </button>
        </form>
      </div>

      <div className="space-y-6">
        {posts.map((post) => (
          <div key={post.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-semibold mb-1">{post.title}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Posted by {post.author} • {post.timestamp}
                </p>
              </div>
            </div>
            
            <p className="mb-6">{post.content}</p>
            
            <div className="flex items-center space-x-6 text-sm">
              <button className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-primary-500">
                <ThumbsUp size={18} />
                <span>{post.likes}</span>
              </button>
              <button className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-primary-500">
                <MessageSquare size={18} />
                <span>{post.comments}</span>
              </button>
              <button className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-primary-500">
                <Share2 size={18} />
                <span>Share</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Community;